package com.library.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.library.model.Book;

@RestController
@RequestMapping("/api/books")
public class BookController {

    // ArrayList stores book records temporarily in memory.
    private final List<Book> books = new ArrayList<>();

    public BookController() {
        books.add(new Book(101, "The Alchemist", "Paulo Coelho", "Fiction", 5));
        books.add(new Book(102, "Wings of Fire", "A.P.J. Abdul Kalam", "Biography", 3));
        books.add(new Book(103, "Clean Code", "Robert C. Martin", "Technology", 4));
    }

    // b) Add a new book
    @PostMapping
    public ResponseEntity<?> addBook(@RequestBody Book book) {
        if (book.getId() == null || findBook(book.getId()).isPresent()) {
            return ResponseEntity.status(HttpStatus.CONFLICT)
                    .body("Book ID is missing or already exists.");
        }

        books.add(book);
        return ResponseEntity.status(HttpStatus.CREATED).body(book);
    }

    // c) Retrieve all books
    @GetMapping
    public ResponseEntity<List<Book>> getAllBooks() {
        return ResponseEntity.ok(books);
    }

    // c) Retrieve one book using its ID
    @GetMapping("/{id}")
    public ResponseEntity<?> getBookById(@PathVariable Integer id) {
        Optional<Book> book = findBook(id);

        if (book.isPresent()) {
            return ResponseEntity.ok(book.get());
        }

        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Book not found with ID: " + id);
    }

    // d) Update book details using its ID
    @PutMapping("/{id}")
    public ResponseEntity<?> updateBook(@PathVariable Integer id, @RequestBody Book updatedBook) {
        Optional<Book> existingBook = findBook(id);

        if (existingBook.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Book not found with ID: " + id);
        }

        Book book = existingBook.get();
        book.setTitle(updatedBook.getTitle());
        book.setAuthor(updatedBook.getAuthor());
        book.setCategory(updatedBook.getCategory());
        book.setAvailableCopies(updatedBook.getAvailableCopies());

        return ResponseEntity.ok(book);
    }

    // e) Delete a book using its ID
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteBook(@PathVariable Integer id) {
        Optional<Book> book = findBook(id);

        if (book.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body("Book not found with ID: " + id);
        }

        books.remove(book.get());
        return ResponseEntity.ok("Book deleted successfully.");
    }

    private Optional<Book> findBook(Integer id) {
        return books.stream()
                .filter(book -> book.getId().equals(id))
                .findFirst();
    }
}
